import { get } from "api/api";
import { NewsIface } from "interface/NewsIface";

const parseTime = (timestamp: number): string => {
  const d = new Date(timestamp);
  let month = d.getMonth();

  let res = "";
  if (d.getDay() < 10) {
    res += "0" + d.getDay();
  } else {
    res += d.getDay();
  }
  res += "/";
  if (month < 10) {
    res += "0" + month;
  } else {
    res += month;
  }
  res += d.getFullYear();

  return res;
};

export async function getNewsList(from: number, count: number = 9) {
  const res = await get<NewsIface[]>("post", {
    from,
    count,
    public: true,
  });
  if (res.data) {
    for (const news of res.data) {
      news.date = parseTime(news.time);
    }
  }
  return res;
}

export async function getOneNews(postId: number) {
  const res = await get<NewsIface>("post", {
    public: true,
    postId,
  });
  if (res.data) {
    res.data.date = parseTime(res.data.time);
  }
  return res;
}
