import { faAngleLeft, faAngleRight } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { getNewsList } from "helper/api-helper";
import { useEffect, useState } from "react";
import ReactPaginate from "react-paginate";
import News from "../../components/News";
import NewsItem from "../../components/NewsItem";
import { NewsIface } from "../../interface/NewsIface";

const Container = () => {
  const itemsPerPage = 9;
  const [pageCount, setPageCount] = useState(0);
  const [totalItems, setTotalItems] = useState<number>();
  const [newsList, setNewsList] = useState<NewsIface[]>();

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await getNewsList(pageCount, itemsPerPage);
        if (res.error_code === 0) {
          const totalItems = res.extraData["count"];
          const totalPages = totalItems / itemsPerPage;
          setTotalItems(Math.ceil(totalPages));
          setNewsList(res.data);
        } else {
          alert(res.message);
        }
      } catch (error) {
        alert(error);
      }
    };
    fetch();
  }, [pageCount]);

  // useEffect(() => {
  //   // Fetch items from another resources.
  //   const endOffset = itemOffset + itemsPerPage;
  //   console.log(`Loading items from ${itemOffset} to ${endOffset}`);
  //   // setCurrentItems(items.slice(itemOffset, endOffset));

  //   setPageCount(Math.ceil(endOffset / itemsPerPage));
  // }, [itemOffset, itemsPerPage, totalItems]);

  const handlePageClick = (event: { selected: number }) => {
    const newOffset = (event.selected * itemsPerPage) % (totalItems ?? 1);
    console.log("==== ~ handlePageClick ~ newOffset", newOffset);

    setPageCount(newOffset);
  };

  return (
    <>
      <div className="bg-[linear-gradient(90deg,_#57A6FF_0%,_#0086BA_102.57%)]">
        <h2 className="text-white text-2xl text-center font-bold pt-[42px] pb-8 sm:pt-6 sm:pb-[18px]">
          TIN TỨC NỔI BẬT
        </h2>
        <div className="mt-6 sm:mt-0 xl:ml-[188px] lg:ml-[120px] md:ml-[60px] xl:mr-[188px] lg:mr-[120px] md:mr-[60px] sm:mx-4">
          <News
            height={"news"}
            color={"text-white"}
            titleColor={"text-white"}
          ></News>
        </div>
      </div>
      <h2 className="text-2xl text-center font-bold mt-16">DANH SÁCH</h2>
      <h2 className="text-2xl text-center font-bold mb-9">TIN TỨC - SỰ KIỆN</h2>
      {/* flex-row justify-between gap-x-1 gap-y-8 */}
      {/* <div className="flex lg:mx-[188px] flex-wrap sm:flex-col"> */}
      <div className="sm:px-4 grid gap-9 sm:gap-0 xl:mx-[188px] lg:mx-[120px] md:mx-[60px] sm:w-full sm:grid-cols-1 md:grid-cols-2 grid-cols-3 mb-14">
        {newsList?.map((news, index) => (
          <div key={index}>
            <NewsItem
              url={news.path + "/" + news.postId}
              image={news.thumbnail}
              title={news.title}
              date={news.date}
              desc={news.description}
            ></NewsItem>
            {index < newsList.length - 1 && (
              <div className="hidden sm:block w-full h-px my-4  bg-[#E6EAED]"></div>
            )}
          </div>
        ))}
      </div>
      <div className="flex justify-center mb-12">
        <ReactPaginate
          breakLabel="..."
          onPageChange={handlePageClick}
          pageRangeDisplayed={2}
          marginPagesDisplayed={1}
          pageCount={totalItems ?? 1}
          pageLinkClassName="page-item bg-[#f3f3f4]"
          previousLabel={<FontAwesomeIcon icon={faAngleLeft} />}
          nextLabel={<FontAwesomeIcon icon={faAngleRight} />}
          previousLinkClassName="my-auto page-item bg-[#f3f3f4]"
          nextLinkClassName="my-auto page-item bg-[#f3f3f4]"
          breakLinkClassName="page-item"
          containerClassName="pagination flex "
          activeLinkClassName="bg-[#FFA557] text-white"
        />
      </div>
    </>
  );
};

export default Container;
