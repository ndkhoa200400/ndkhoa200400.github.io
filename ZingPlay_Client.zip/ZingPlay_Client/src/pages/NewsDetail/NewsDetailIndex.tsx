import { FC } from "react";
import Header from "components/Header";
import { Container } from "./Container";

const NewsDetailsIndex: FC = () => {
  return (
    <div>
      <Header></Header>
      <Container></Container>
    </div>
  );
};

export default NewsDetailsIndex;
