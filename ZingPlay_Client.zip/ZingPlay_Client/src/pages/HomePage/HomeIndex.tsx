import Header from "../../components/Header"
import Container from "./Container"

const HomeIndex = () => {
    return(
        <div>
            <Header></Header>
            <Container></Container>
        </div>
    )
}

export default HomeIndex