import { NewsItemRow } from "components/NewsItemRow";
import { getNewsList } from "helper/api-helper";
import { NewsIface } from "interface/NewsIface";
import { FC, useEffect, useState } from "react";

const decodeHtmlEntities = (content: string) => {
  const text = document.createElement("textarea");
  text.innerHTML = content;
  return text.value;
};
export const Content: FC<{
  news: NewsIface;
}> = ({ news }) => {
  const [newsList, setNewsList] = useState<NewsIface[]>();

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await getNewsList(0, 4);
        if (res.error_code === 0) {
          setNewsList(res.data);
        } else {
          alert(res.message);
        }
      } catch (error) {
        alert(error);
      }
    };
    fetch();
  }, []);
  return (
    // <div>{Parser((news.content.replace(/&lt;/g, "<").replace(/&gt;/g, ">")))}</div>
    <div className="flex mt-6  sm:block xl:pl-[188px] lg:pl-[120px] md:pl-[60px]  sm:block xl:pr-[155px] lg:pr-[58px] md:pr-[30px]">
      <div
        className="text-align flex-[6] mr-14 lg:mr-10"
        dangerouslySetInnerHTML={{ __html: decodeHtmlEntities(news.content) }}
      ></div>
      <div className="flex-[3]">
        <div className="hidden sm:block w-full h-px my-4 bg-[#E6EAED]"></div>
        <div className="text-[18px] font-bold mt-3 mb-8 sm:mb-2 leading-7">
          Tin tức - sự kiện khác
        </div>
        <div className=" flex flex-col justify-between mb-6">
          {newsList?.map((val, index) => {
            return (
              <>
                <NewsItemRow
                  key={index}
                  color={"text-black"}
                  val={val}
                  titleColor="text-black"
                  textColorClass="text-[#545B78]"
                />
                {index < newsList.length - 1 && (
                  <div className="w-full h-px my-4 bg-[#E6EAED]"></div>
                )}
              </>
            );
          })}
        </div>
      </div>
    </div>
  );
};
