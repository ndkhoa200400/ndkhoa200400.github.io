import { FC } from "react";
import { NewsIface } from "interface/NewsIface";

const NewsTitle: FC<{ news: NewsIface }> = ({ news }) => {
  const titleNewsIcon = require("assets/img/title_news_icon.png");

  return (
    <div className="flex sm:block xl:px-[188px] lg:px-[120px] md:px-[60px] sm:bg-white  bg-[#F2F4F8] sm:w-full">
      <div
        className="mr-8 sm:m-0 "
        style={{
          minWidth: "50%",
        }}
      >
        <img src={news.thumbnail} alt="news" className="w-full" />
      </div>
      <div className="flex sm:mx-4   flex-col mt-8 sm:mt-4">
        <div>
          <img src={titleNewsIcon} alt="icon" />
        </div>
        <div className="text-[24px] font-bold mt-3 mb-8 sm:mb-2 leading-7">
          {news.title}
        </div>
        <span className="text-[14px] leading-5 text-[#545B78]">
          {news.date}
        </span>
      </div>
    </div>
  );
};

export default NewsTitle;
