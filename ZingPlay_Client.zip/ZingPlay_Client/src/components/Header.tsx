import { faAngleUp, faBars } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import { Link } from "react-router-dom";

interface game {
  url: string;
  name: string;
  logo: string;
}

const gameList: game[] = [
  {
    url: "https://www.play.zing.vn/zp/tlmn",
    name: "Tiến lên miền nam",
    logo: require("../assets/img/TLMN.png"),
  },
  {
    url: "https://www.play.zing.vn/zp/tala",
    name: "Tá Lả",
    logo: require("../assets/img/TaLa.png"),
  },
  {
    url: "ttps://www.play.zing.vn/zp/maubinh",
    name: "Mậu Binh",
    logo: require("../assets/img/MB.png"),
  },
];

const Header = () => {
  const adultLogo = require("../assets/img/adult_logo.png");
  const logo = require("../assets/img/logo.png");

  return (
    <div className="sm:h-[60px] lg:h-[90px]">
      <nav className="flex justify-between h-full">
        <ul className="flex">
          <img src={String(adultLogo)} alt="Adult Logo" className="" />
          <Link to={"/"} className="flex h-full my-auto ml-6 items-center">
            <img src={String(logo)} alt="Logo" className="sm:h-11" />
          </Link>
        </ul>
        <ul className="sm:hidden flex my-auto mr-76 font-medium">
          <li className="mx-8">
            <Link to={"/"}>Trang chủ</Link>
          </li>
          <li className="mx-8">
            <Link to={"/news"}>Tin tức - sự kiện</Link>
          </li>
          <li className="mx-8 flex relative group ease-in-out duration-1000">
            <div>Chơi ngay</div>
            <FontAwesomeIcon icon={faAngleUp} className="ml-1" />
            <div className=" ease-in-out duration-200 block opacity-0 invisible group-hover:visible group-hover:opacity-100 absolute right-0 top-5 bg-white z-10 w-[200px] shadow-lg rounded">
              <ul className="">
                {gameList.map((val, index) => (
                  <React.Fragment key={index}>
                    <li
                      className="py-2 px-2.5 divide-y divide-slate-200 hover:bg-gray-100"
                    >
                      <Link to={val.url} target={"_blank"} className="flex">
                        <img
                          src={val.logo}
                          alt="Game Logo"
                          className="bg-cover w-8 h-8"
                        />
                        <span className="ml-2 block my-auto">{val.name}</span>
                      </Link>
                    </li>

                    {index < gameList.length - 1 && (
                      <div className="w-full h-px my-1 bg-[#E6EAED]"></div>
                    )}
                  </React.Fragment>
                ))}
              </ul>
            </div>
          </li>
        </ul>
        <ul className="hidden sm:flex top-0 right-0 absolute h-[60px] pr-[21px] text-2xl my-auto items-center">
          <FontAwesomeIcon icon={faBars} />
        </ul>
      </nav>
      <div className="w-full h-px opacity-30 bg-[linear-gradient(90deg,_#FFDA57_0%,_#FF7354_102.57%)]"></div>
    </div>
  );
};

export default Header;
