export interface NewsIface {
  path: string;
  thumbnail: string;
  title: string;
  description: string;
  date: string;
  content: string;
  gameId: number;
  public: boolean;
  time: number;
  game: string;
  postId: number;
}
