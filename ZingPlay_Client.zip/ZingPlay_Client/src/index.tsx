import ReactDOM from "react-dom/client";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./index.css";
import HomeIndex from "./pages/HomePage/HomeIndex";
import NewsIndex from "./pages/News/NewsIndex";
import NewsDetailsIndex from "./pages/NewsDetail/NewsDetailIndex";
import reportWebVitals from "./reportWebVitals";

const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);
root.render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<HomeIndex />} />
      <Route path="/news">
        <Route index element={<NewsIndex />}></Route>
        <Route path="/news/:path/:postId" element={<NewsDetailsIndex />}></Route>
      </Route>
    </Routes>
  </BrowserRouter>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
